#include "../timestamp.h"
#include <stdlib.h>
int main()
{
	struct time_struct t1,t2,t3;
	struct f_fp offset;

	t1.timescale = 65536;
	t1.timestamp.Uf_i.Xf_ui = 1379983024;
	t1.timestamp.f_uf = 0;

	t2.timescale = 65536;
	t2.timestamp.Uf_i.Xf_ui = 1379983029;
	t2.timestamp.f_uf = 0;

	offset = get_offset(&t2,&t1);

	printf("offset     : %lld,%lld\n",offset.Uf_i.Xf_ui,offset.f_uf);

	struct time_struct t4 = add(&t1,&offset);
	struct time_struct t5 = subtract(&t2,&offset);

	printf("add result : %lld,%lld\n",t4.timestamp.Uf_i.Xf_ui,t4.timestamp.f_uf);
	printf("sub result : %lld,%lld\n",t5.timestamp.Uf_i.Xf_ui,t5.timestamp.f_uf);

	return 0;
}

/*
[root@limifly-vpc TestCase]# gcc test6.c /root/gsoc-lib/libtimestamp.so -o test6
[root@limifly-vpc TestCase]# ./test6
offset     : 5,0
add result : 1379983029,0
sub result : 1379983024,0
*/
