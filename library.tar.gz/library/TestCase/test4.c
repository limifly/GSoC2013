#include "../timestamp.h"
#include <stdlib.h>
int main()
{
	struct time_struct t1,t2,gps1,gps2;
	gps1.timescale = 65536;
	gps1.timestamp.Uf_i.Xf_ui = 1341187175;
	gps1.timestamp.f_uf = 413415000;
	convert_from_gps(&gps1,&t1,196609); //iers bulletina-xxv-027
	printf("gps1           : %lld,%lld\n",gps1.timestamp.Uf_i.Xf_ui,gps1.timestamp.f_uf);
	printf("IERS-A xxv-027 : %lld,%lld\n",t1.timestamp.Uf_i.Xf_ui,t1.timestamp.f_uf);



	gps2.timescale = 65536; //iers bulletina-xxvi-035
	gps2.timestamp.Uf_i.Xf_ui = 1341014399;//1341057599;
	gps2.timestamp.f_uf = 413146000;
	convert_from_gps(&gps2,&t2,196609); //iers bulletina-xxv-027
	printf("gps2 (leap_sec): %lld,%lld\n",gps2.timestamp.Uf_i.Xf_ui,gps2.timestamp.f_uf);
	printf("IERS-A xxv-027 : %lld,%lld\n",t2.timestamp.Uf_i.Xf_ui,t2.timestamp.f_uf);

	return 0;
}
/*
[root@limifly-vpc TestCase]# gcc test4.c /root/gsoc-lib/libtimestamp.so -o test4
[root@limifly-vpc TestCase]# ./test4
gps1           : 1341187175,413415000
IERS-A xxv-027 : 1341187200,0
gps2 (leap_sec): 1341014399,413146000
IERS-A xxv-027 : 1341014423,999722225
*/
