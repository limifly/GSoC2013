#include "../timestamp.h"
#include <stdlib.h>
int main()
{
	struct time_struct t1,t2,t3,gps1,gps2,gps3;
	t1.timescale = 196609; //iers bulletina-xxv-027
	t1.timestamp.Uf_i.Xf_ui = 1341100800;
	t1.timestamp.f_uf = 0;
	convert_to_gps(&t1,&gps1);
	printf("IERS-A xxv-027 : %lld,%lld\n",t1.timestamp.Uf_i.Xf_ui,t1.timestamp.f_uf);
	printf("gps1           : %lld,%lld\n",gps1.timestamp.Uf_i.Xf_ui,gps1.timestamp.f_uf);


	t2.timescale = 196610; //iers bulletina-xxvi-035
	t2.timestamp.Uf_i.Xf_ui = 1377475200;
	t2.timestamp.f_uf = 0;
	convert_to_gps(&t2,&gps2);
	printf("IERS-A xxvi-035: %lld,%lld\n",t2.timestamp.Uf_i.Xf_ui,t2.timestamp.f_uf);
	printf("gps2           : %lld,%lld\n",gps2.timestamp.Uf_i.Xf_ui,gps2.timestamp.f_uf);

	t3.timescale = 196610; //iers bulletina-xxvi-035
	t3.timestamp.Uf_i.Xf_ui = 1377518400;
	t3.timestamp.f_uf = 0;
	convert_to_gps(&t3,&gps3);
	printf("IERS-A xxvi-035: %lld,%lld\n",t3.timestamp.Uf_i.Xf_ui,t3.timestamp.f_uf);
	printf("gps3           : %lld,%lld\n",gps3.timestamp.Uf_i.Xf_ui,gps3.timestamp.f_uf);

	return 0;
}
/*
[root@limifly-vpc TestCase]# gcc test3.c /root/gsoc-lib/libtimestamp.so -o test3
[root@limifly-vpc TestCase]# ./test3
IERS-A xxv-027 : 1341100800,0
gps1           : 1341100775,586777000
IERS-A xxvi-035: 1377475200,0
gps2           : 1377475174,960010000
IERS-A xxvi-035: 1377518400,0
gps3           : 1377518374,960244500
*/
