TIMESTAMP_LIBRARY_PATH=/root/gsoc-lib/libtimestamp.so
gcc test1.c $TIMESTAMP_LIBRARY_PATH -o test1
gcc test2.c $TIMESTAMP_LIBRARY_PATH -o test2
gcc test3.c $TIMESTAMP_LIBRARY_PATH -o test3
gcc test4.c $TIMESTAMP_LIBRARY_PATH -o test4
gcc test5.c $TIMESTAMP_LIBRARY_PATH -o test5
gcc test6.c $TIMESTAMP_LIBRARY_PATH -o test6
gcc test7.c $TIMESTAMP_LIBRARY_PATH -o test7 -lrt
gcc test8.c $TIMESTAMP_LIBRARY_PATH -o test8
