#include "../timestamp.h"
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

int main()
{
	struct time_struct t1,t2,t3;
	my_gettimeofday(&t1);
	printf("exp_error(first time): %d\n",t1.exp_error);

	my_gettimeofday(&t2);
	printf("exp_error(second time): %d\n",t2.exp_error);

	int i,j,k;
	for (i=0;i<1000000;i++) {
		for (j=0;j<5000;j++) {
			k = 0;
		}
	}

	my_gettimeofday(&t3);
	printf("exp_error(third time): %d\n",t3.exp_error);
	return 0;
}

/*
[root@limifly-vpc TestCase]# gcc test8.c /root/gsoc-lib/libtimestamp.so -o test8
[root@limifly-vpc TestCase]# ./test8
exp_error(first time): 10245
exp_error(second time): 10245
exp_error(third time): 10255
*/
