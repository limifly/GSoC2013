#include "../timestamp.h"
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

int main()
{
	struct time_struct t1,t2,t3;
	my_gettimeofday(&t1);
	printf("discontinuity count: %d\n",t1.discon_count);

	struct timeval temp1;

	gettimeofday(&temp1,NULL);
	settimeofday(&temp1,NULL);
	printf("call settimeofday()\n");
	my_gettimeofday(&t2);
	printf("discontinuity count: %d\n",t2.discon_count);

	struct timespec temp2;
	clock_gettime(CLOCK_REALTIME, &temp2);
	clock_settime(CLOCK_REALTIME, &temp2);
	printf("call clock_settime()\n");
	my_gettimeofday(&t3);
	printf("discontinuity count: %d\n",t3.discon_count);
	return 0;
}

/*
[root@limifly-vpc TestCase]# gcc test7.c /root/gsoc-lib/libtimestamp.so -o test7 -lrt
[root@limifly-vpc TestCase]# ./test7
discontinuity count: 1
call settimeofday()
discontinuity count: 2
call clock_settime()
discontinuity count: 3
*/
