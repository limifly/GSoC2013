#include "../timestamp.h"
#include <stdlib.h>
int main()
{
	struct time_struct t1,t2,gps;
	gps.timestamp.Uf_i.Xf_ui = 1379977290;
	gps.timestamp.f_uf = 0;
	gps.timescale = 65536;

	convert_from_gps(&gps,&t1,131328); //2006a
	convert_from_gps(&gps,&t2,131329); //2013d

	printf("gps       : %lld,%lld\n",gps.timestamp.Uf_i.Xf_ui,gps.timestamp.f_uf);
	printf("utc(2006a): %lld,%lld\n",t1.timestamp.Uf_i.Xf_ui,t1.timestamp.f_uf);
	printf("utc(2013d): %lld,%lld\n",t2.timestamp.Uf_i.Xf_ui,t2.timestamp.f_uf);
	return 0;
}
/*
[root@limifly-vpc TestCase]# gcc test2.c /root/gsoc-lib/libtimestamp.so -o test2
[root@limifly-vpc TestCase]# ./test2
gps       : 1379977290,0
utc(2006a): 1379977313,0
utc(2013d): 1379977315,0
*/
