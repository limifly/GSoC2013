#include "../timestamp.h"
#include <stdlib.h>
int main()
{
	struct time_struct t1,t2,t3;
	int i;
	my_gettimeofday(&t1);
	convert_to_gps(&t1,&t2);
	convert_from_gps(&t2,&t3,131328);

	printf("utc(2013d) : %lld,%lld\n",t1.timestamp.Uf_i.Xf_ui,t1.timestamp.f_uf);
	printf("gps tick   : %lld,%lld\n",t2.timestamp.Uf_i.Xf_ui,t2.timestamp.f_uf);
	printf("utc(2006a) : %lld,%lld\n",t3.timestamp.Uf_i.Xf_ui,t3.timestamp.f_uf);
	printf("Compare1   : %d\n",compare_timestamp(&t2,&t1));

	struct time_struct t4,t5,t6,t7;
	t4.timescale = 65536;
	t4.timestamp.Uf_i.Xf_ui = 1379983024;
	t4.timestamp.f_uf = 0;
	t5.timescale = 65536;
	t5.timestamp.Uf_i.Xf_ui = 1379983023;
	t5.timestamp.f_uf = 0;
	t6.timescale = 65536;
	t6.timestamp.Uf_i.Xf_ui = 1379983025;
	t6.timestamp.f_uf = 0;
	t7.timescale = 65536;
	t7.timestamp.Uf_i.Xf_ui = 1379983024;
	t7.timestamp.f_uf = 0;
	printf("Compare2   : %d\n",compare_timestamp(&t4,&t5));
	printf("Compare3   : %d\n",compare_timestamp(&t4,&t6));
	printf("Compare4   : %d\n",compare_timestamp(&t4,&t7));
	return 0;
}

/*
[root@limifly-vpc TestCase]# gcc test5.c /root/gsoc-lib/libtimestamp.so -o test5
[root@limifly-vpc TestCase]# ./test5
utc(2013d) : 1379983288,855395839
gps tick   : 1379983263,855395839
utc(2006a) : 1379983286,855395839
Compare1   : 0
Compare2   : 1
Compare3   : -1
Compare4   : 0
*/
