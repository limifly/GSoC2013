import sys,string
from datetime import datetime
#sys.argv = ['compile.py','bulletina-xxvi-035.txt']
#sys.argv = ['compile.py','bulletina-xxv-027.txt']

if (len(sys.argv) != 2):
    print "Usage: python compile.py bulletina-xxv-027.txt"
    sys.exit(1)
srcFileName = sys.argv[1]

f = open(srcFileName)
lines = f.readlines()
f.close()
pos = -1
result = []
for i in range(0,len(lines)):
    if lines[i].find("IERS Rapid Service") != -1:
        pos = i;
        break;
if pos != -1:
    for i in range(pos+3,pos+10):
        temp = lines[i].strip().split()
        yearFrom = string.atoi(temp[0])+2000
        monthFrom = string.atoi(temp[1])
        dayFrom = string.atoi(temp[2])
        offsetFrom = string.atoi(temp[8].replace('0.',''))*1000
        result.append((yearFrom,monthFrom,dayFrom,offsetFrom))

for i in range(pos+10,len(lines)):
    if lines[i].find("UT1-UTC(sec)") != -1:
        for j in range(i+1,len(lines)):
            temp = lines[j].strip().split()
            if (len(temp) == 7):
                yearFrom = string.atoi(temp[0])
                monthFrom = string.atoi(temp[1])
                dayFrom = string.atoi(temp[2])
                offset = string.atoi(temp[6].replace('0.',''))*10000
                result.append((yearFrom,monthFrom,dayFrom,offset))
            else:
                break
        break;
f = open((srcFileName.split('.'))[0]+'.dat','w')
print>>f, len(result)-1
for i in range(0,len(result)-1):
    yearFrom = result[i][0]
    monthFrom = result[i][1]
    dayFrom = result[i][2]
    yearTo = result[i+1][0]
    monthTo = result[i+1][1]
    dayTo = result[i+1][2]
    offsetFrom = result[i][3]
    offsetTo = result[i+1][3]
    isLeapSecond = 0
    if abs(offsetFrom-offsetTo) > 500000000:
        isLeapSecond = 1
    utcTickStart = int((datetime(yearFrom,monthFrom,dayFrom) - datetime(1970, 1, 1)).total_seconds())
    utcTickEnd = int((datetime(yearTo,monthTo,dayTo) - datetime(1970, 1, 1)).total_seconds())
    localTickStartSec = utcTickStart
    localTickEndSec = utcTickEnd
    localTickStartMs = offsetFrom
    localTickEndMs = offsetTo
    if (localTickStartMs < 0):
        localTickStartMs += 1000000000
        localTickStartSec -= 1
    if (localTickEndMs < 0):
        localTickEndMs += 1000000000
        localTickEndSec -= 1
    print>>f, utcTickStart,utcTickEnd,offsetFrom,offsetTo,isLeapSecond,localTickStartSec,localTickStartMs,localTickEndSec,localTickEndMs
f.close()
