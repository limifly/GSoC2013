gcc -c tzcode/localtime.c -o localtime.o
gcc -c timestamp.c -o timestamp.o
gcc -shared -o libtimestamp.so localtime.o timestamp.o -lrt