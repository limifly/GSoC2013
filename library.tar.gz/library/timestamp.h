#include <stdio.h>
#include <time.h>
#include <string.h>

#ifndef int64
#define int64 long long
#endif

#ifndef u_int64
#define u_int64 unsigned long long
#endif

#ifndef int32
#define int32 int
#endif

#ifndef u_int32
#define u_int32 unsigned int
#endif

struct f_fp{
	union {
		u_int64 Xf_ui;
		int64 Xf_i;
	} Uf_i;
	u_int64 f_uf;
};

struct time_struct {
    struct f_fp timestamp; //timestamp
    struct f_fp exp_offset; //expected offset
    u_int32 exp_error; //expected error
    u_int32 timescale; //timescale indicator
    u_int32 discon_count; //discontinuity counter
    u_int32 version; //version of timestamp
};

struct IERS_struct
{
	int local_start_tick;
	int local_end_tick;
	int offset_start;
	int offset_end;
	int is_leapsecond;
	int utc_start_sec;
	int utc_start_ms;
	int utc_end_sec;
	int utc_end_ms;
};

int total_count = 0;
struct IERS_struct iers_data_list[500];

int my_gettimeofday(struct time_struct* ret);
int compare_timestamp(struct time_struct* t1, struct time_struct* t2);
struct time_struct subtract(struct time_struct* ts, struct f_fp* delta);
struct time_struct add(struct time_struct* ts, struct f_fp* delta);
struct f_fp get_offset(struct time_struct* t1, struct time_struct* t2);
int convert_to_gps(struct time_struct* src, struct time_struct* dst);
int convert_from_gps(struct time_struct* src, struct time_struct* dst, u_int32 dst_timescale);
void GetTzVersion(int timescale, char* ret);
void GetIersVersion(int timescale, char* ret);
int iers_load(char* file_name);

extern time_t my_time2posix(time_t t, char* tzVer);
extern time_t my_posix2time(time_t t, char* tzVer);
