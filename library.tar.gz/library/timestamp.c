#include "timestamp.h"

int my_gettimeofday(struct time_struct* ret)
{
	//CLOCK_ID is of no use now
	struct timespec sys_timestamp;
	clock_gettime(CLOCK_REALTIME, &sys_timestamp);
	ret->timestamp.Uf_i.Xf_ui = sys_timestamp.tv_sec;
	ret->timestamp.f_uf = sys_timestamp.tv_nsec;
	int discontinuity_counter,expected_offset_second,expected_error;
	unsigned int expected_offset_nanosecond;
	syscall(351,&discontinuity_counter,&expected_error,&expected_offset_second, &expected_offset_nanosecond);
	ret->discon_count = discontinuity_counter;
	ret->exp_error = expected_error;
	struct f_fp exp_offset;
	exp_offset.Uf_i.Xf_i = expected_offset_second;
	exp_offset.f_uf = expected_offset_nanosecond;
	ret->exp_offset = exp_offset;
	ret->timescale = 131329; // 0.2.1.1, tz2013d
	ret->version = 1;
	return 0;
}
int compare_timestamp(struct time_struct* t1, struct time_struct* t2)
{
	struct time_struct gps_t1,gps_t2;
	if (t1->timescale == 65536) {
		gps_t1 = *t1;
	}
	else {
		convert_to_gps(t1,&gps_t1);
	}
	if (t2->timescale == 65536) {
		gps_t2 = *t2;
	}
	else {
		convert_to_gps(t2,&gps_t2);
	}
	//Return 0 if t1=t2, 1 if t1>t2, -1 if t1<t2
	int ret = 0;
	if (gps_t1.timestamp.Uf_i.Xf_ui != gps_t2.timestamp.Uf_i.Xf_ui)
	{
		if (gps_t1.timestamp.Uf_i.Xf_ui > gps_t2.timestamp.Uf_i.Xf_ui)
			ret = 1;
		else
			ret = -1;
	}
	else
	{
		if (gps_t1.timestamp.f_uf != gps_t2.timestamp.f_uf)
		{
			if (gps_t1.timestamp.f_uf > gps_t2.timestamp.f_uf)
				ret = 1;
			else
				ret = -1;
		}
		else
			ret = 0;
	}
	return ret;
}

struct time_struct subtract(struct time_struct* ts, struct f_fp* delta)
{
	struct time_struct ret;
	int shift = 0;
	if (ts->timestamp.f_uf < delta->f_uf)
	{
		ret.timestamp.f_uf = ts->timestamp.f_uf + 1000000000 - delta->f_uf;
		shift = 1;
	}
	else
		ret.timestamp.f_uf = ts->timestamp.f_uf - delta->f_uf;
	ret.timestamp.Uf_i.Xf_ui = ts->timestamp.Uf_i.Xf_ui - delta->Uf_i.Xf_i - shift;
	ret.timescale = ts->timescale;
	ret.version = ts->version;
	ret.exp_error = ts->exp_error;
	ret.exp_offset = ts->exp_offset;
	return ret;
}

struct time_struct add(struct time_struct* ts, struct f_fp* delta)
{
	struct time_struct ret;
	int shift = 0;
	ret.timestamp.f_uf = ts->timestamp.f_uf + delta->f_uf;
	shift = (ret.timestamp.f_uf - (ret.timestamp.f_uf % 1000000000)) / 1000000000;
	ret.timestamp.f_uf = ret.timestamp.f_uf % 1000000000;
	ret.timestamp.Uf_i.Xf_ui = ts->timestamp.Uf_i.Xf_ui + delta->Uf_i.Xf_i + shift;
	ret.timescale = ts->timescale;
	ret.version = ts->version;
	ret.exp_error = ts->exp_error;
	ret.exp_offset = ts->exp_offset;
	return ret;
}

struct f_fp get_offset(struct time_struct* t1, struct time_struct* t2)
{
	//Get offset of t1 - t2
	struct f_fp ret;
	if (t1->timescale != t2->timescale) {
		ret.Uf_i.Xf_ui = 0;
		ret.f_uf = 0;
		return ret;
	}
	int shift = 0;
	if (t1->timestamp.f_uf < t2->timestamp.f_uf)
	{
		ret.f_uf = t1->timestamp.f_uf + 1000000000 - t2->timestamp.f_uf;
		shift = 1;
	}
	else
		ret.f_uf = t1->timestamp.f_uf - t2->timestamp.f_uf;
	ret.Uf_i.Xf_i = (int64)t1->timestamp.Uf_i.Xf_ui - (int64)t2->timestamp.Uf_i.Xf_ui - shift;
	return ret;
}

int convert_to_gps(struct time_struct* src, struct time_struct* dst)
{
	//if src is in GPS, 0.1.0.0
	if (src->timescale == 65536)
	{
		dst->timestamp = src->timestamp;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = src->timescale;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
		return 0;
	}
	else if (src->timescale >= 131328 && src->timescale <= 131583) // in tz data 0.2.1.0 - 0.2.1.255
	{
		char tzVer[10];
		GetTzVersion(src->timescale,tzVer);
		dst->timestamp.Uf_i.Xf_ui = my_time2posix(src->timestamp.Uf_i.Xf_ui,tzVer);
        dst->timestamp.f_uf = src->timestamp.f_uf;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = 65536;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
		return 0;
	}
	else if(src->timescale >= 196608 && src->timescale <= 196863) // iers 0.3.0.0 - 0.3.0.255
	{
		//IERS-A timescale
		char iers_data_name[20];
		char tzVer[10];
		GetIersVersion(src->timescale,iers_data_name);
		GetTzVersion(0,tzVer);
		iers_load(iers_data_name);
		u_int64 src_second = src->timestamp.Uf_i.Xf_ui, src_nano_second = src->timestamp.f_uf;
		u_int64 dst_second=src_second, dst_nano_second=src_nano_second;

		if (total_count < 7) {
			printf("error: less than 7 iers data\n");
			return 1;
		}
		if (src_second < iers_data_list[0].local_start_tick) {
			printf("error: lower bound overflow\n");
			return 1;
		}
		if (src_second > iers_data_list[total_count-1].local_end_tick) {
			printf("error: upper bound overflow\n");
			return 1;
		}
		int i=0,offset=0;
		for (i=0;i<total_count;i++) {
			if (src_second >= iers_data_list[i].local_start_tick
				&& src_second < iers_data_list[i].local_end_tick) {
				offset = iers_data_list[i].offset_start+(iers_data_list[i].offset_end-iers_data_list[i].offset_start)/86400.0*(src_second-iers_data_list[i].local_start_tick);
				if (dst_nano_second < offset) {
					dst_nano_second = dst_nano_second + (1000000000-offset);
					dst_second -= 1;
				}
				else {
					dst_nano_second -= offset;
				}
				//printf("utc time: %d %d\n",dst_second,iers_timestamp_ms);
				break;
			}
		}
		dst->timestamp.Uf_i.Xf_ui = my_time2posix(dst_second,tzVer);
		dst->timestamp.f_uf = dst_nano_second;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = 65536;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
		return 0;
	}
	return 1;

}

int convert_from_gps(struct time_struct* src, struct time_struct* dst, u_int32 dst_timescale)
{
	//if dst timescale is in GPS, 0.1.0.0
	if (dst_timescale == 65536)
	{
		dst->timestamp = src->timestamp;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = src->timescale;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
		return 0;
	}
	else if (dst_timescale >= 131328 && dst_timescale <= 131583) // in tz data 0.2.1.0 - 0.2.1.255
	{
		char tz_ver[10];
		GetTzVersion(dst_timescale,tz_ver);
		dst->timestamp.Uf_i.Xf_ui = my_posix2time(src->timestamp.Uf_i.Xf_ui,tz_ver);
        dst->timestamp.f_uf = src->timestamp.f_uf;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = dst_timescale;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
		return 0;
	}
	else if(dst_timescale >= 196608 && dst_timescale <= 196863) // iers 0.3.0.0 - 0.3.0.255
	{
		char tz_ver[10];
		GetTzVersion(0,tz_ver);		//Get lastest tz database version
		char iers_data_name[20];
		GetIersVersion(dst_timescale,iers_data_name);
		iers_load(iers_data_name);
		u_int64 src_second=0,src_nano_second=0,dst_second=0,dst_nano_second=0;
		src_second = my_posix2time(src->timestamp.Uf_i.Xf_ui,tz_ver);
		src_nano_second = src->timestamp.f_uf;
		//printf("convert_from_gps: %lld,%lld\n",src_second,src_nano_second);
		if (total_count < 7) {
			printf("error: less than 7 iers data\n");
			return 1;
		}
		if (	(src_second < iers_data_list[0].utc_start_sec)
			||	(src_second == iers_data_list[0].utc_start_sec && src_nano_second < iers_data_list[0].utc_start_ms)
			||	(src_second > iers_data_list[total_count-1].utc_end_sec)
			||	(src_second == iers_data_list[total_count-1].utc_end_sec && src_nano_second > iers_data_list[total_count-1].utc_end_ms)) {
			printf("lower or upper bound overflow\n");
			return 1;
		}
		int i=0;
		long long utc_start=0,utc_end=0,utc_temp=0,offset=0;
		double divisor = 0;
		int offset_sec=0,offset_ms=0;
		int iers_timestamp_sec = 0, iers_timestamp_ms = 0;
		for (i=0;i<total_count;i++) {
			if (src_second >= iers_data_list[i].utc_start_sec
				&& src_nano_second >= iers_data_list[i].utc_start_ms
				&& src_second <= iers_data_list[i].utc_end_sec
				&& src_nano_second < iers_data_list[i].utc_end_ms) {
				//printf("%d,%d,%d,%d\n",iers_data_list[i].utc_start_sec,iers_data_list[i].utc_start_ms,iers_data_list[i].utc_end_sec,iers_data_list[i].utc_end_ms);
				utc_start = iers_data_list[i].utc_start_sec;
				utc_start = utc_start*1000000000 + iers_data_list[i].utc_start_ms;
				utc_end = iers_data_list[i].utc_end_sec;
				utc_end = utc_end*1000000000 + iers_data_list[i].utc_end_ms;
				utc_temp = src_second;
				utc_temp = utc_temp*1000000000+src_nano_second;
				if (iers_data_list[i].is_leapsecond == 1) {
					divisor = 86401;
				}
				else {
					divisor = 86400;
				}
				offset = (iers_data_list[i].local_end_tick - iers_data_list[i].local_start_tick)/divisor*(utc_temp-utc_start);
				offset_ms = offset % 1000000000;
				offset_sec = offset/1000000000;
				dst_nano_second = offset_ms;
				dst_second = iers_data_list[i].local_start_tick + offset_sec;
				//printf("iers time: %d %d\n",iers_timestamp_sec,iers_timestamp_ms);
				break;
			}
		}
		dst->timestamp.Uf_i.Xf_ui = dst_second;
		dst->timestamp.f_uf = dst_nano_second;
		dst->exp_error = src->exp_error;
		dst->exp_offset = src->exp_offset;
		dst->timescale = dst_timescale;
		dst->discon_count = src->discon_count;
		dst->version = src->version;
        return 0;
	}
	return 1;
}
void GetTzVersion(int timescale, char* ret)
{
	if(timescale == 0) { //newest version
		strcpy(ret,"2013d");
		return;
	}
	else if(timescale == 131328)
	{
		strcpy(ret,"2006a");
		return;
	}
	else if (timescale = 131329)
	{
		strcpy(ret,"2013d");
		return;
	}
	else
		return;
}

void GetIersVersion(int timescale, char* ret)
{
	if(timescale == 196609)	//0.3.0.1
	{
		strcpy(ret,"/root/gsoc-lib/iers/bulletina-xxv-027.dat");
		return;
	}
	else if (timescale = 196610) //0.3.0.2
	{
		strcpy(ret,"/root/gsoc-lib/iers/bulletina-xxvi-035.dat");
		return;
	}
	else
		return;
}

int iers_load(char* file_name) {
	FILE* stream;
	char str[200];
	int i;
	stream = fopen(file_name,"r");
	if (fgets(str,200,stream) != NULL)
	{
		sscanf(str,"%d",&total_count);
	}
	for (i=0;i<total_count;i++)
	{
		if (fgets(str,200,stream) != NULL)
		{
			sscanf(str,"%d %d %d %d %d %d %d %d %d",
				&iers_data_list[i].local_start_tick,
				&iers_data_list[i].local_end_tick,
				&iers_data_list[i].offset_start,
				&iers_data_list[i].offset_end,
				&iers_data_list[i].is_leapsecond,
				&iers_data_list[i].utc_start_sec,
				&iers_data_list[i].utc_start_ms,
				&iers_data_list[i].utc_end_sec,
				&iers_data_list[i].utc_end_ms);
			//printf("%d %d %d %d %d %d %d %d %d\n",data_list[i].local_start_tick,data_list[i].local_end_tick,data_list[i].offset_start,data_list[i].offset_end,data_list[i].is_leapsecond,data_list[i].utc_start_sec,data_list[i].utc_start_ms,data_list[i].utc_end_sec,data_list[i].utc_end_ms);
		}
		else
		{
			printf("Error: line count not match\n");
			fclose(stream);
			return 1;
		}
	}
	fclose(stream);
	return 0;
}
